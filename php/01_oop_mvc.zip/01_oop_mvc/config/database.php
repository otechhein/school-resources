<?php

define('DB_HOST', 'your-db-host');
define('DB_PORT', 'your-db-port');
define('DB_NAME', 'your-db-name');
define('DB_USER', 'your-db-user');
define('DB_PASS', 'your-db-pass');