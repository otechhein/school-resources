<?php
// DB Params
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', '02_oop_mvc');

// App Root
define('APPROOT', dirname(dirname(__FILE__)));
// URL Root
define('URLROOT', 'http://localhost/otechnique/training/php/02_oop_mvc');
// Site Name
define('SITENAME', 'Emmizy MVC Frame');
// App Version
define('APPVERSION', '1.0.0');
